import React from "react";
import "./App.css";

const OddRows = () => {
  return (
    <div>
      <div className="white"></div>
      <div className="black"></div>
      <div className="white"></div>
      <div className="black"></div>
      <div className="white"></div>
      <div className="black"></div>
      <div className="white"></div>
      <div className="black"></div>
    </div>
  );
};
export default OddRows;
