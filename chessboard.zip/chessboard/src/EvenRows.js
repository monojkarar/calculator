import React from "react";
import "./App.css";

const EvenRows = () => {
  return (
    <div>
      <div className="black"></div>
      <div className="white"></div>
      <div className="black"></div>
      <div className="white"></div>
      <div className="black"></div>
      <div className="white"></div>
      <div className="black"></div>
      <div className="white"></div>
    </div>
  );
};
export default EvenRows;
